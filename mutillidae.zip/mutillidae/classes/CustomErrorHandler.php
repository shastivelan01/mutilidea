<?php 

/**
 * CustomErrorHandler class for formatting and handling errors.
 * 
 * This class is responsible for formatting errors in different output formats (HTML, JSON, XML)
 * while considering security levels to encode output to prevent XSS and other security vulnerabilities.
 * 
 * Known Vulnerabilities: Cross Site Scripting, Cross Site Request Forgery, Application Exception, SQL Exception
 */
class CustomErrorHandler {
	
	protected $encodeOutput = false;
	protected $mSecurityLevel = 0;
	protected $ESAPI = null;
	protected $Encoder = null;
	protected $suppressErrorMessages = false;
	
	protected $mLine = "";
	protected $mCode = "";
	protected $mFile = "";
	protected $mMessage = "";
	protected $mTrace = "";
	protected $mDiagnosticInformation = "";

	/**
	 * Formats error details as an HTML table.
	 *
	 * @param Exception $e The exception object.
	 * @param string $pDiagnosticInformation Additional diagnostic information.
	 * @return string HTML formatted error information.
	 */
	private function doFormatErrorAsHTMLTable(Exception $e, $pDiagnosticInformation) {
		$lSupressedMessage = "Sorry. An error occurred. Support has been notified. Not allowed to give out errors at this security level.";
		
		$this->setErrorProperties($e, $pDiagnosticInformation);
		
		$lHTML = $this->suppressErrorMessages ? 
			'<tr><td class="error-label">Message</td><td class="error-detail">' . htmlspecialchars($lSupressedMessage, ENT_QUOTES, 'UTF-8') . '</td></tr>' :
			'<tr><td class="error-label">Line</td><td class="error-detail">' . htmlspecialchars($this->mLine, ENT_QUOTES, 'UTF-8') . '</td></tr>
			 <tr><td class="error-label">Code</td><td class="error-detail">' . htmlspecialchars($this->mCode, ENT_QUOTES, 'UTF-8') . '</td></tr>
			 <tr><td class="error-label">File</td><td class="error-detail">' . htmlspecialchars($this->mFile, ENT_QUOTES, 'UTF-8') . '</td></tr>
			 <tr><td class="error-label">Message</td><td class="error-detail">' . htmlspecialchars($this->mMessage, ENT_QUOTES, 'UTF-8') . '</td></tr>
			 <tr><td class="error-label">Trace</td><td class="error-detail">' . htmlspecialchars($this->mTrace, ENT_QUOTES, 'UTF-8') . '</td></tr>
			 <tr><td class="error-label">Diagnostic Information</td><td class="error-detail">' . htmlspecialchars($this->mDiagnosticInformation, ENT_QUOTES, 'UTF-8') . '</td></tr>';

		return '<fieldset>
			<legend>Error Message</legend>
			<table>
				<tr><td colspan="2">&nbsp;</td></tr>
				<tr>
					<td colspan="2" class="error-header">Failure is always an option</td>
				</tr>
				' . $lHTML . '
				<tr>
					<td colspan="2" class="error-header" style="text-align: center;"><a href="set-up-database.php">Click here to reset the DB</a></td>
				</tr>
				<tr><td colspan="2">&nbsp;</td></tr>
			</table>
		</fieldset>';
	}

	/**
	 * Sets the security level for encoding output.
	 *
	 * @param int $pSecurityLevel The security level.
	 */
	private function doSetSecurityLevel($pSecurityLevel) {
		$this->mSecurityLevel = (int)$pSecurityLevel;
		
		switch ($this->mSecurityLevel) {
			case 0:
			case 1:
				$this->encodeOutput = false;
				$this->suppressErrorMessages = false;
				break;
			case 2:
			case 3:
			case 4:
			case 5:
				$this->encodeOutput = true;
				$this->suppressErrorMessages = true;
				break;
			default:
				$this->encodeOutput = false;
				$this->suppressErrorMessages = false;
		}
	}

	/**
	 * Formats the exception message for output.
	 *
	 * @param Exception $e The exception object.
	 * @param string $pDiagnosticInformation Additional diagnostic information.
	 * @return string Formatted exception message.
	 */
	private function formatExceptionMessage(Exception $e, $pDiagnosticInformation) {
		return sprintf("%s on line %d: %s %s (%d) [%s] <br />\n",
			htmlspecialchars($e->getFile(), ENT_QUOTES, 'UTF-8'),
			$e->getLine(),
			htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'),
			htmlspecialchars($pDiagnosticInformation, ENT_QUOTES, 'UTF-8'),
			$e->getCode(),
			get_class($e)
		);
	}

	/**
	 * Sets properties of the error based on security level.
	 *
	 * @param Exception $pException The exception object.
	 * @param string $pDiagnosticInformation Additional diagnostic information.
	 */
	private function setErrorProperties(Exception $pException, $pDiagnosticInformation) {
		if (!$this->encodeOutput) {
			$this->mLine = $pException->getLine();
			$this->mCode = $pException->getCode();
			$this->mFile = $pException->getFile();
			$this->mMessage = $pException->getMessage();
			$this->mTrace = $pException->getTraceAsString();
			$this->mDiagnosticInformation = $pDiagnosticInformation;
		} else {
			$this->mLine = $this->Encoder->encodeForHTML($pException->getLine());
			$this->mCode = $this->Encoder->encodeForHTML($pException->getCode());
			$this->mFile = $this->Encoder->encodeForHTML($pException->getFile());
			$this->mMessage = $this->Encoder->encodeForHTML($pException->getMessage());
			$this->mTrace = $this->Encoder->encodeForHTML($pException->getTraceAsString());
			$this->mDiagnosticInformation = $this->Encoder->encodeForHTML($pDiagnosticInformation);
		}
	}

	/**
	 * Constructs the CustomErrorHandler and initializes ESAPI.
	 *
	 * @param string $pPathToESAPI Path to the ESAPI directory.
	 * @param int $pSecurityLevel Initial security level.
	 */
	public function __construct($pPathToESAPI, $pSecurityLevel) {
		$this->doSetSecurityLevel($pSecurityLevel);
		
		require_once $pPathToESAPI . 'ESAPI.php';
		$this->ESAPI = new ESAPI($pPathToESAPI . 'ESAPI.xml');
		$this->Encoder = $this->ESAPI->getEncoder();
	}

	/**
	 * Sets the security level for encoding output.
	 *
	 * @param int $pSecurityLevel The security level.
	 */
	public function setSecurityLevel($pSecurityLevel) {
		$this->doSetSecurityLevel($pSecurityLevel);
	}

	/**
	 * Gets the formatted exception message, including previous exceptions if any.
	 *
	 * @param Exception $e The exception object.
	 * @param string $pDiagnosticInformation Additional diagnostic information.
	 * @return string Formatted exception message.
	 */
	public function getExceptionMessage(Exception $e, $pDiagnosticInformation) {		
		$lExceptionMessage = "";
		
		while ($e) {
			$lExceptionMessage .= $this->formatExceptionMessage($e, $pDiagnosticInformation);
			$e = $e->getPrevious();
		}
		
    	return $lExceptionMessage;
	}

	/**
	 * Formats the error as JSON.
	 *
	 * @param Exception $e The exception object.
	 * @param string $pDiagnosticInformation Additional diagnostic information.
	 * @return string JSON formatted error information.
	 */
	public function FormatErrorJSON(Exception $e, $pDiagnosticInformation) {
		return $this->doFormatErrorJSON($e, $pDiagnosticInformation);
	}

	/**
	 * Formats the error as XML.
	 *
	 * @param Exception $e The exception object.
	 * @param string $pDiagnosticInformation Additional diagnostic information.
	 * @return string XML formatted error information.
	 */
	public function FormatErrorXML(Exception $e, $pDiagnosticInformation) {
		return $this->doFormatErrorXML($e, $pDiagnosticInformation);
	}

	/**
	 * Formats the error as JSON.
	 *
	 * @param Exception $e The exception object.
	 * @param string $pDiagnosticInformation Additional diagnostic information.
	 * @return string JSON formatted error information.
	 */
	private function doFormatErrorJSON(Exception $e, $pDiagnosticInformation) {
		$lSupressedMessage = "Sorry. An error occurred. Support has been notified. Not allowed to give out errors at this security level.";
		
		$this->setErrorProperties($e, $pDiagnosticInformation);
		
		$lJSON = $this->suppressErrorMessages ? 
			'{
				"Exception": {
					"Message": "' . htmlspecialchars($lSupressedMessage, ENT_QUOTES, 'UTF-8') . '",
					"DiagnosticInformation": "' . htmlspecialchars($lSupressedMessage, ENT_QUOTES, 'UTF-8') . '"
				}
			}' :
			'{
				"Exception": {
					"Line": "' . htmlspecialchars($this->mLine, ENT_QUOTES, 'UTF-8') . '",
					"Code": "' . htmlspecialchars($this->mCode, ENT_QUOTES, 'UTF-8') . '",
					"File": "' . htmlspecialchars($this->mFile, ENT_QUOTES, 'UTF-8') . '",
					"Message": "' . htmlspecialchars($this->mMessage, ENT_QUOTES, 'UTF-8') . '",
					"Trace": "' . htmlspecialchars($this->mTrace, ENT_QUOTES, 'UTF-8') . '",
					"DiagnosticInformation": "' . htmlspecialchars($this->mDiagnosticInformation, ENT_QUOTES, 'UTF-8') . '"
				}
			}';
		
		return $lJSON;
	}

	/**
	 * Formats the error as XML.
	 *
	 * @param Exception $e The exception object.
	 * @param string $pDiagnosticInformation Additional diagnostic information.
	 * @return string XML formatted error information.
	 */
	private function doFormatErrorXML(Exception $e, $pDiagnosticInformation) {
		$lSupressedMessage = "Sorry. An error occurred. Support has been notified. Not allowed to give out errors at this security level.";
		
		$this->setErrorProperties($e, $pDiagnosticInformation);
		
		$lXML = $this->suppressErrorMessages ? 
			"<exception>
				<message>" . htmlspecialchars($lSupressedMessage, ENT_XML1, 'UTF-8') . "</message>
				<diagnosticInformation>" . htmlspecialchars($lSupressedMessage, ENT_XML1, 'UTF-8') . "</diagnosticInformation>
			</exception>" :
			"<exception>
				<line>" . htmlspecialchars($this->mLine, ENT_XML1, 'UTF-8') . "</line>
				<code>" . htmlspecialchars($this->mCode, ENT_XML1, 'UTF-8') . "</code>
				<file>" . htmlspecialchars($this->mFile, ENT_XML1, 'UTF-8') . "</file>
				<message>" . htmlspecialchars($this->mMessage, ENT_XML1, 'UTF-8') . "</message>
				<trace>" . htmlspecialchars($this->mTrace, ENT_XML1, 'UTF-8') . "</trace>
				<diagnosticInformation>" . htmlspecialchars($this->mDiagnosticInformation, ENT_XML1, 'UTF-8') . "</diagnosticInformation>
			</exception>";

		return $lXML;
	}
}
?>
