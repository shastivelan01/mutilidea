<?php
/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *	   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/**
 * Most of the work of the {@link LoggerPatternLayout} class 
 * is delegated to the {@link LoggerPatternParser} class.
 * 
 * <p>It is this class that parses conversion patterns and creates
 * a chained list of {@link LoggerPatternConverter} converters.</p>
 * 
 * @version $Revision: 795734 $ 
 * @package log4php
 * @subpackage helpers
 *
 * @since 0.3
 */
class LoggerPatternParser {

    const LOG4PHP_LOGGER_PATTERN_PARSER_ESCAPE_CHAR = '%';
    
    const LOG4PHP_LOGGER_PATTERN_PARSER_LITERAL_STATE = 0;
    const LOG4PHP_LOGGER_PATTERN_PARSER_CONVERTER_STATE = 1;
    const LOG4PHP_LOGGER_PATTERN_PARSER_MINUS_STATE = 2;
    const LOG4PHP_LOGGER_PATTERN_PARSER_DOT_STATE = 3;
    const LOG4PHP_LOGGER_PATTERN_PARSER_MIN_STATE = 4;
    const LOG4PHP_LOGGER_PATTERN_PARSER_MAX_STATE = 5;
    
    const LOG4PHP_LOGGER_PATTERN_PARSER_FULL_LOCATION_CONVERTER = 1000;
    const LOG4PHP_LOGGER_PATTERN_PARSER_METHOD_LOCATION_CONVERTER = 1001;
    const LOG4PHP_LOGGER_PATTERN_PARSER_CLASS_LOCATION_CONVERTER = 1002;
    const LOG4PHP_LOGGER_PATTERN_PARSER_FILE_LOCATION_CONVERTER = 1003;
    const LOG4PHP_LOGGER_PATTERN_PARSER_LINE_LOCATION_CONVERTER = 1004;
    
    const LOG4PHP_LOGGER_PATTERN_PARSER_RELATIVE_TIME_CONVERTER = 2000;
    const LOG4PHP_LOGGER_PATTERN_PARSER_THREAD_CONVERTER = 2001;
    const LOG4PHP_LOGGER_PATTERN_PARSER_LEVEL_CONVERTER = 2002;
    const LOG4PHP_LOGGER_PATTERN_PARSER_NDC_CONVERTER = 2003;
    const LOG4PHP_LOGGER_PATTERN_PARSER_MESSAGE_CONVERTER = 2004;
    
    const LOG4PHP_LOGGER_PATTERN_PARSER_DATE_FORMAT_ISO8601 = 'Y-m-d H:i:s,u'; 
    const LOG4PHP_LOGGER_PATTERN_PARSER_DATE_FORMAT_ABSOLUTE = 'H:i:s';
    const LOG4PHP_LOGGER_PATTERN_PARSER_DATE_FORMAT_DATE = 'd M Y H:i:s,u';

    private $state;
    private $currentLiteral;
    private $patternLength;
    private $i;
    
    /**
     * @var LoggerPatternConverter
     */
    private $head = null;
     
    /**
     * @var LoggerPatternConverter
     */
    private $tail = null;
    
    /**
     * @var LoggerFormattingInfo
     */
    private $formattingInfo;
    
    /**
     * @var string pattern to parse
     */
    private $pattern;

    /**
     * Constructor 
     *
     * @param string $pattern
     */
    public function __construct($pattern) {
        $this->pattern = $pattern;
        $this->patternLength = strlen($pattern);
        $this->formattingInfo = new LoggerFormattingInfo();
        $this->state = self::LOG4PHP_LOGGER_PATTERN_PARSER_LITERAL_STATE;
    }

    /**
     * @param LoggerPatternConverter $pc
     */
    public function addToList($pc) {
        if ($this->head === null) {
            $this->head = $pc;
            $this->tail = $this->head;
        } else {
            $this->tail->next = $pc;
            $this->tail = $this->tail->next;
        }
    }

    /**
     * Extracts options enclosed in braces.
     *
     * @return string|null
     */
    public function extractOption() {
        if ($this->i < $this->patternLength && $this->pattern[$this->i] === '{') {
            $end = strpos($this->pattern, '}', $this->i);
            if ($end !== false) {
                $r = substr($this->pattern, $this->i + 1, $end - $this->i - 1);
                $this->i = $end + 1;
                return $r;
            }
        }
        return null;
    }

    /**
     * Extracts a precision option.
     *
     * @return int
     */
    public function extractPrecisionOption() {
        $opt = $this->extractOption();
        $r = 0;
        if ($opt !== null && is_numeric($opt)) {
            $r = (int) $opt;
            if ($r <= 0) {
                $r = 0;
            }
        }
        return $r;
    }

    /**
     * Parses the pattern and processes each character.
     *
     * @return LoggerPatternConverter|null
     */
    public function parse() {
        $this->i = 0;
        $this->currentLiteral = '';
    
        while ($this->i < $this->patternLength) {
            $c = $this->pattern[$this->i++];
    
            switch ($this->state) {
                case self::LOG4PHP_LOGGER_PATTERN_PARSER_LITERAL_STATE:
                    if ($this->i == $this->patternLength) {
                        $this->currentLiteral .= $c;
                    }
                    continue;

                case self::LOG4PHP_LOGGER_PATTERN_PARSER_CONVERTER_STATE:
                    $this->currentLiteral .= $c;
                    switch ($c) {
                        case '-':
                            $this->formattingInfo->leftAlign = true;
                            break;

                        case '.':
                            $this->state = self::LOG4PHP_LOGGER_PATTERN_PARSER_DOT_STATE;
                            break;

                        default:
                            if (ctype_digit($c)) {
                                $this->formattingInfo->min = (int) $c;
                                $this->state = self::LOG4PHP_LOGGER_PATTERN_PARSER_MIN_STATE;
                            } else {
                                $this->finalizeConverter($c);
                            }
                            break;
                    }
                    break;

                case self::LOG4PHP_LOGGER_PATTERN_PARSER_MIN_STATE:
                    $this->currentLiteral .= $c;
                    if (ctype_digit($c)) {
                        $this->formattingInfo->min = ($this->formattingInfo->min * 10) + (int) $c;
                    } elseif ($c === '.') {
                        $this->state = self::LOG4PHP_LOGGER_PATTERN_PARSER_DOT_STATE;
                    } else {
                        $this->finalizeConverter($c);
                    }
                    break;

                case self::LOG4PHP_LOGGER_PATTERN_PARSER_DOT_STATE:
                    $this->currentLiteral .= $c;
                    if (ctype_digit($c)) {
                        $this->formattingInfo->max = (int) $c;
                        $this->state = self::LOG4PHP_LOGGER_PATTERN_PARSER_MAX_STATE;
                    } else {
                        $this->state = self::LOG4PHP_LOGGER_PATTERN_PARSER_LITERAL_STATE;
                    }
                    break;

                case self::LOG4PHP_LOGGER_PATTERN_PARSER_MAX_STATE:
                    $this->currentLiteral .= $c;
                    if (ctype_digit($c)) {
                        $this->formattingInfo->max = ($this->formattingInfo->max * 10) + (int) $c;
                    } else {
                        $this->finalizeConverter($c);
                        $this->state = self::LOG4PHP_LOGGER_PATTERN_PARSER_LITERAL_STATE;
                    }
                    break;
                
                default:
                    // Handle unexpected state if needed
                    break;
            }
        }
        
        if (strlen($this->currentLiteral) > 0) {
            $this->addToList(new LoggerLiteralPatternConverter($this->currentLiteral));
        }
        return $this->head;
    }

    /**
     * Finalizes and creates the appropriate pattern converter based on the character.
     *
     * @param string $c
     */
    public function finalizeConverter($c) {
        $pc = null;
        switch ($c) {
            case 'c':
                $pc = new LoggerCategoryPatternConverter($this->formattingInfo, $this->extractPrecisionOption());
                break;
            case 'C':
                $pc = new LoggerClassNamePatternConverter($this->formattingInfo, $this->extractPrecisionOption());
                break;
            case 'd':
                $dateFormatStr = self::LOG4PHP_LOGGER_PATTERN_PARSER_DATE_FORMAT_ISO8601;
                $dOpt = $this->extractOption();
                if ($dOpt !== null) {
                    $dateFormatStr = $dOpt;
                }
                $df = $this->resolveDateFormat($dateFormatStr);
                $pc = new LoggerDatePatternConverter($this->formattingInfo, $df);
                break;
            case 'F':
                $pc = new LoggerLocationPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_FILE_LOCATION_CONVERTER);
                break;
            case 'l':
                $pc = new LoggerLocationPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_FULL_LOCATION_CONVERTER);
                break;
            case 'L':
                $pc = new LoggerLocationPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_LINE_LOCATION_CONVERTER);
                break;
            case 'm':
                $pc = new LoggerBasicPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_MESSAGE_CONVERTER);
                break;
            case 'M':
                $pc = new LoggerLocationPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_METHOD_LOCATION_CONVERTER);
                break;
            case 'p':
                $pc = new LoggerBasicPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_LEVEL_CONVERTER);
                break;
            case 'r':
                $pc = new LoggerBasicPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_RELATIVE_TIME_CONVERTER);
                break;
            case 't':
                $pc = new LoggerBasicPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_THREAD_CONVERTER);
                break;
            case 'u':
                if ($this->i < $this->patternLength) {
                    $cNext = $this->pattern[$this->i];
                    if (ctype_digit($cNext)) {
                        $pc = new LoggerUserFieldPatternConverter($this->formattingInfo, (string) (ord($cNext) - ord('0')));
                        $this->i++;
                    }
                }
                break;
            case 'x':
                $pc = new LoggerBasicPatternConverter($this->formattingInfo, self::LOG4PHP_LOGGER_PATTERN_PARSER_NDC_CONVERTER);
                break;
            case 'X':
                $xOpt = $this->extractOption();
                $pc = new LoggerMDCPatternConverter($this->formattingInfo, $xOpt);
                break;
            default:
                $pc = new LoggerLiteralPatternConverter($this->currentLiteral);
        }
        $this->addConverter($pc);
    }

    /**
     * Resolves the date format string to use.
     *
     * @param string $dateFormatStr
     * @return string
     */
    private function resolveDateFormat($dateFormatStr) {
        switch ($dateFormatStr) {
            case 'ISO8601':
                return self::LOG4PHP_LOGGER_PATTERN_PARSER_DATE_FORMAT_ISO8601;
            case 'ABSOLUTE':
                return self::LOG4PHP_LOGGER_PATTERN_PARSER_DATE_FORMAT_ABSOLUTE;
            case 'DATE':
                return self::LOG4PHP_LOGGER_PATTERN_PARSER_DATE_FORMAT_DATE;
            default:
                return $dateFormatStr ?: self::LOG4PHP_LOGGER_PATTERN_PARSER_DATE_FORMAT_ISO8601;
        }
    }

    /**
     * Adds the converter to the list and resets the state.
     *
     * @param LoggerPatternConverter $pc
     */
    public function addConverter($pc) {
        $this->currentLiteral = '';
        $this->addToList($pc);
        $this->state = self::LOG4PHP_LOGGER_PATTERN_PARSER_LITERAL_STATE;
        $this->formattingInfo->reset();
    }
}
